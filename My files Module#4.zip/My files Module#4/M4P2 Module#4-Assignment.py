greeting = input("Hello, possible pirate! What's the password?")
if greeting == ("Arrr!"):
	print("Go away, pirate.")
else:
        print("Greetings, hater of pirates!")
